CREATE DATABASE IF NOT EXISTS my_store
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE my_store;

CREATE TABLE IF NOT EXISTS users (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(190) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS products (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  description TEXT NULL,
  price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  image_url VARCHAR(500) NULL,
  stock INT UNSIGNED NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS cart_items (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNSIGNED NOT NULL,
  product_id INT UNSIGNED NOT NULL,
  quantity INT UNSIGNED NOT NULL DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY unique_user_product (user_id, product_id),
  CONSTRAINT fk_cart_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_cart_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Add sample products when they do not already exist.
INSERT INTO products (name, description, price, image_url, stock)
SELECT 'Wireless Headphones', 'Comfortable over-ear wireless headphones with clear sound.', 250000.00, 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80', 20
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Wireless Headphones');

INSERT INTO products (name, description, price, image_url, stock)
SELECT 'Running Sneakers', 'Lightweight sneakers for everyday use and running.', 390000.00, 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80', 15
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Running Sneakers');

INSERT INTO products (name, description, price, image_url, stock)
SELECT 'Travel Backpack', 'A practical backpack for school, work, and travel.', 175000.00, 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=80', 30
WHERE NOT EXISTS (SELECT 1 FROM products WHERE name = 'Travel Backpack');

-- Update the three original demo rows if the database was imported earlier.
-- These IDs match the original sample products in this starter project.
UPDATE products SET name = 'Wireless Headphones', description = 'Comfortable over-ear wireless headphones with clear sound.', price = 250000.00, image_url = 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=80', stock = 20 WHERE id = 1;
UPDATE products SET name = 'Running Sneakers', description = 'Lightweight sneakers for everyday use and running.', price = 390000.00, image_url = 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=80', stock = 15 WHERE id = 2;
UPDATE products SET name = 'Travel Backpack', description = 'A practical backpack for school, work, and travel.', price = 175000.00, image_url = 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=80', stock = 30 WHERE id = 3;
