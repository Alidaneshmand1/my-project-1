# React + Vite Shop Backend (PHP, MySQL, XAMPP)

## Folder structure
Place this folder at `C:\xampp\htdocs\shop-api`.

```text
shop-api/
  config.php
  register.php
  login.php
  me.php
  logout.php
  products.php
  cart.php
  database.sql
  README.md
```

## Setup
1. Open XAMPP Control Panel and start **Apache** and **MySQL**.
2. Open `http://localhost/phpmyadmin`.
3. Select **Import**, choose `database.sql`, and click **Import**.
4. Place the `shop-api` folder inside `C:\xampp\htdocs\`.
5. Open `http://localhost/shop-api/products.php`. You should see JSON containing the products.
6. Start your React/Vite project. Vite commonly runs at `http://localhost:5173`.

## Database settings
The default local settings in `config.php` are:
- Host: `localhost`
- Database: `my_store`
- Username: `root`
- Password: empty

If your MySQL root account has a password, update `DB_PASS` in `config.php`.

## Product images
Each product has an `image_url` field. The sample SQL fills it with image URLs so the API includes an image for every demo product. In React, use `product.image_url` as the image `src`, for example:

```jsx
<img src={product.image_url} alt={product.name} />
```

The demo images are hosted externally, so the browser needs an internet connection to load them. You can replace these URLs with your own image URLs later.

## API endpoints
- `POST /register.php` — create an account
- `POST /login.php` — log in
- `GET /me.php` — get the current logged-in user
- `POST /logout.php` — log out
- `GET /products.php` — list products
- `GET /cart.php` — get the cart
- `POST /cart.php` — add a product to the cart
- `PATCH /cart.php` — update a cart item's quantity
- `DELETE /cart.php` — remove a product from the cart

Base URL: `http://localhost/shop-api`

For React requests that use the login session, include `credentials: "include"`. For requests that send JSON, set the `Content-Type: application/json` header.

## Example: fetch products
```js
const API = "http://localhost/shop-api";
const response = await fetch(`${API}/products.php`);
const result = await response.json();
console.log(result.products);
```

## Example: register
```js
const response = await fetch("http://localhost/shop-api/register.php", {
  method: "POST",
  credentials: "include",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({
    name: "Alex",
    email: "alex@example.com",
    password: "ChangeThisPassword123"
  })
});
const result = await response.json();
console.log(result);
```

## Example: add to cart
```js
const response = await fetch("http://localhost/shop-api/cart.php", {
  method: "POST",
  credentials: "include",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ product_id: 1, quantity: 1 })
});
const result = await response.json();
console.log(result);
```

## Response format
Successful response: `{ "success": true, ... }`

Error response: `{ "success": false, "message": "An error message" }`

## Security note
This starter project is intended for local development. Before deploying publicly, configure HTTPS, secure session cookies, rate limiting, hosting settings, and additional validation. User passwords are stored as hashes, not as plain text.
