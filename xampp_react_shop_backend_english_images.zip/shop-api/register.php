<?php
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Allow: POST');
    json_response(['success' => false, 'message' => 'Only POST requests are allowed.'], 405);
}

$data = read_json();
$name = trim((string)($data['name'] ?? ''));
$email = strtolower(trim((string)($data['email'] ?? '')));
$password = (string)($data['password'] ?? '');

if ($name === '' || mb_strlen($name) > 100) {
    json_response(['success' => false, 'message' => 'Name is required (maximum 100 characters).'], 422);
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 190) {
    json_response(['success' => false, 'message' => 'Enter a valid email address.'], 422);
}
if (strlen($password) < 8) {
    json_response(['success' => false, 'message' => 'Password must be at least 8 characters long.'], 422);
}

try {
    $stmt = $pdo->prepare('INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)');
    $stmt->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT)]);
    $userId = (int)$pdo->lastInsertId();
    session_regenerate_id(true);
    $_SESSION['user_id'] = $userId;
    json_response(['success' => true, 'message' => 'Registration successful.', 'user' => ['id' => $userId, 'name' => $name, 'email' => $email]], 201);
} catch (PDOException $e) {
    if ($e->getCode() === '23000') {
        json_response(['success' => false, 'message' => 'This email address is already registered.'], 409);
    }
    error_log('Register failed: ' . $e->getMessage());
    json_response(['success' => false, 'message' => 'Registration failed. Please try again.'], 500);
}
