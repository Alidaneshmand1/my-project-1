<?php
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('Allow: GET');
    json_response(['success' => false, 'message' => 'Only GET requests are allowed.'], 405);
}

$userId = require_user_id();
$stmt = $pdo->prepare('SELECT id, name, email FROM users WHERE id = ? LIMIT 1');
$stmt->execute([$userId]);
$user = $stmt->fetch();

if (!$user) {
    unset($_SESSION['user_id']);
    json_response(['success' => false, 'message' => 'Account not found. Please log in again.'], 401);
}
$user['id'] = (int)$user['id'];
json_response(['success' => true, 'user' => $user]);
