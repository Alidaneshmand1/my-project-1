<?php
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    header('Allow: GET');
    json_response(['success' => false, 'message' => 'Only GET requests are allowed.'], 405);
}

$stmt = $pdo->query('SELECT id, name, description, price, image_url, stock FROM products ORDER BY id DESC');
$products = $stmt->fetchAll();
foreach ($products as &$product) {
    $product['id'] = (int)$product['id'];
    $product['price'] = (float)$product['price'];
    $product['stock'] = (int)$product['stock'];
}
unset($product);
json_response(['success' => true, 'products' => $products]);
