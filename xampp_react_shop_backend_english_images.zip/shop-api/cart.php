<?php
require_once __DIR__ . '/config.php';

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($method === 'GET') {
    $userId = require_user_id();
    $stmt = $pdo->prepare(
        'SELECT p.id AS product_id, p.name, p.description, p.price, p.image_url, p.stock, ci.quantity
         FROM cart_items ci
         JOIN products p ON p.id = ci.product_id
         WHERE ci.user_id = ?
         ORDER BY ci.updated_at DESC'
    );
    $stmt->execute([$userId]);
    $items = $stmt->fetchAll();
    $total = 0.0;
    foreach ($items as &$item) {
        $item['product_id'] = (int)$item['product_id'];
        $item['quantity'] = (int)$item['quantity'];
        $item['stock'] = (int)$item['stock'];
        $item['price'] = (float)$item['price'];
        $item['line_total'] = round($item['price'] * $item['quantity'], 2);
        $total += $item['line_total'];
    }
    unset($item);
    json_response(['success' => true, 'items' => $items, 'total' => round($total, 2)]);
}

if ($method === 'POST') {
    $userId = require_user_id();
    $data = read_json();
    $productId = filter_var($data['product_id'] ?? null, FILTER_VALIDATE_INT);
    $quantity = filter_var($data['quantity'] ?? 1, FILTER_VALIDATE_INT);
    if (!$productId || !$quantity || $quantity < 1 || $quantity > 99) {
        json_response(['success' => false, 'message' => 'Invalid product ID or quantity.'], 422);
    }

    try {
        $pdo->beginTransaction();
        $stmt = $pdo->prepare('SELECT id, stock FROM products WHERE id = ? FOR UPDATE');
        $stmt->execute([$productId]);
        $product = $stmt->fetch();
        if (!$product) {
            $pdo->rollBack();
            json_response(['success' => false, 'message' => 'Product not found.'], 404);
        }

        $stmt = $pdo->prepare('SELECT quantity FROM cart_items WHERE user_id = ? AND product_id = ?');
        $stmt->execute([$userId, $productId]);
        $existing = $stmt->fetch();
        $newQuantity = (int)($existing['quantity'] ?? 0) + $quantity;

        if ($newQuantity > (int)$product['stock']) {
            $pdo->rollBack();
            json_response(['success' => false, 'message' => 'Requested quantity exceeds available stock.'], 422);
        }

        if ($existing) {
            $stmt = $pdo->prepare('UPDATE cart_items SET quantity = ? WHERE user_id = ? AND product_id = ?');
            $stmt->execute([$newQuantity, $userId, $productId]);
        } else {
            $stmt = $pdo->prepare('INSERT INTO cart_items (user_id, product_id, quantity) VALUES (?, ?, ?)');
            $stmt->execute([$userId, $productId, $quantity]);
        }
        $pdo->commit();
        json_response(['success' => true, 'message' => 'Product added to cart.']);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log('Cart add failed: ' . $e->getMessage());
        json_response(['success' => false, 'message' => 'Could not add product to cart.'], 500);
    }
}

if ($method === 'PATCH') {
    $userId = require_user_id();
    $data = read_json();
    $productId = filter_var($data['product_id'] ?? null, FILTER_VALIDATE_INT);
    $quantity = filter_var($data['quantity'] ?? null, FILTER_VALIDATE_INT);
    if (!$productId || $quantity === false || $quantity < 1 || $quantity > 99) {
        json_response(['success' => false, 'message' => 'Invalid product ID or quantity.'], 422);
    }

    $stmt = $pdo->prepare('SELECT p.stock FROM products p WHERE p.id = ?');
    $stmt->execute([$productId]);
    $product = $stmt->fetch();
    if (!$product) json_response(['success' => false, 'message' => 'Product not found.'], 404);
    if ($quantity > (int)$product['stock']) {
        json_response(['success' => false, 'message' => 'Requested quantity exceeds available stock.'], 422);
    }

    $stmt = $pdo->prepare('UPDATE cart_items SET quantity = ? WHERE user_id = ? AND product_id = ?');
    $stmt->execute([$quantity, $userId, $productId]);
    if ($stmt->rowCount() === 0) {
        $check = $pdo->prepare('SELECT id FROM cart_items WHERE user_id = ? AND product_id = ?');
        $check->execute([$userId, $productId]);
        if (!$check->fetch()) json_response(['success' => false, 'message' => 'This product is not in your cart.'], 404);
    }
    json_response(['success' => true, 'message' => 'Product quantity updated.']);
}

if ($method === 'DELETE') {
    $userId = require_user_id();
    $data = read_json();
    $productId = filter_var($data['product_id'] ?? null, FILTER_VALIDATE_INT);
    if (!$productId) json_response(['success' => false, 'message' => 'Invalid product ID.'], 422);

    $stmt = $pdo->prepare('DELETE FROM cart_items WHERE user_id = ? AND product_id = ?');
    $stmt->execute([$userId, $productId]);
    json_response(['success' => true, 'message' => 'Product removed from cart.']);
}

header('Allow: GET, POST, PATCH, DELETE');
json_response(['success' => false, 'message' => 'This HTTP method is not supported.'], 405);
